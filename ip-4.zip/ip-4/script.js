class Person {
    constructor(name, mobile) {
      this.name = name;
      this.mobile = mobile;
    }
  
    printDetails() {
      console.log(`Name: ${this.name}, Mobile: ${this.mobile}`);
    }
  }
  
  const processOrder = () => {
    const name = document.getElementById('name').value;
    const mobile = document.getElementById('mobile').value;
    const message = document.getElementById('message').value;
  
    if (mobile.length !== 9) {
      alert('Mobile number must be 9 digits long.');
      return false;
    }
  
    const person = new Person(name, mobile);
    person.printDetails();
  
    const today = new Date();
    const receiptDetails = `Order received for ${name}. Mobile: ${mobile}. Message: ${message}. Receipt generated on ${today.toDateString()}.`;
    
    document.getElementById('receiptDetails').textContent = receiptDetails;
    document.getElementById('receipt').style.display = 'block';
    
    return false;
  };
  
  class Student extends Person {
    constructor(name, mobile, rollNo) {
      super(name, mobile);
      if (rollNo <= 0) throw new Error('Roll number must be greater than zero.');
      this.rollNo = rollNo;
    }
  
    printDetails() {
      console.log(`Name: ${this.name}, Mobile: ${this.mobile}, Roll No: ${this.rollNo}`);
    }
  }
  
  const student = new Student('John Doe', '123456789', 5);
  student.printDetails();
  
  const invalidStudent = () => {
    try {
      new Student('Jane Doe', '987654321', 0);
    } catch (e) {
      alert(e.message);
    }
  };
  
  invalidStudent();
  